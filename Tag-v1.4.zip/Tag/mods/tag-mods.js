/*
 * Tag — extras: gamepad support, handicaps, online play.
 *
 * Loaded as the project's main script (see tools/bundle_mods.py), so it runs
 * before the Construct runtime starts. It talks to the game in two ways:
 *   - the official scripting API (runtime.globalVars, runtime.objects, tick event)
 *   - synthetic keyboard events, so every input source ends up as the same
 *     key presses the game already understands (A/W/D, arrows, J/I/L, F/T/H).
 *
 * Open the options panel with the corner button or the F2 key.
 */
(function () {
  'use strict';
  if (window.__tagMods) return;

  var VERSION = 1;
  var LS_KEY = 'tag.mods.v1';
  var ROOM_PREFIX = 'tagjet-';
  var ROOM_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var MAX_GUESTS = 3;

  // ---- network config. Override before load with window.TAG_NET = {...} ----
  function netConfig() {
    var o = window.TAG_NET || {};
    var opts = { debug: 1, config: { iceServers: o.iceServers || [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:global.stun.twilio.com:3478' }
    ] } };
    if (o.host) opts.host = o.host;
    if (o.port) opts.port = o.port;
    if (o.path) opts.path = o.path;
    if (typeof o.secure === 'boolean') opts.secure = o.secure;
    return opts;
  }

  // ---------------------------------------------------------------- settings
  var cfg = { hcMode: 'off', hcLevel: 2, hintSeen: false };
  try {
    var saved = JSON.parse(localStorage.getItem(LS_KEY) || 'null');
    if (saved) for (var k in saved) cfg[k] = saved[k];
  } catch (e) {}
  function saveCfg() { try { localStorage.setItem(LS_KEY, JSON.stringify(cfg)); } catch (e) {} }

  var runtime = null;       // set by runOnStartup
  var guestMode = false;    // true while joined to someone else's game

  // ------------------------------------------------- engine hooks (early)
  // 1) Keep the WebGL back buffer readable so the host can stream the canvas.
  var origGetContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function (type, attrs) {
    if (this === window.c3canvas && (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl')) {
      attrs = Object.assign({}, attrs || {}, { preserveDrawingBuffer: true });
    }
    return origGetContext.call(this, type, attrs);
  };

  // 2) Route all game audio through one gain node per AudioContext, so we can
  //    (a) tee it into a MediaStream for guests and (b) mute it on a guest.
  var audioContexts = [];
  (function hookAudio() {
    if (typeof AudioNode === 'undefined' || typeof AudioDestinationNode === 'undefined') return;
    var origConnect = AudioNode.prototype.connect;
    var origDisconnect = AudioNode.prototype.disconnect;
    function ensureOut(ctx) {
      if (ctx.__tagOut) return ctx.__tagOut;
      var g = ctx.createGain();
      origConnect.call(g, ctx.destination);
      try {
        if (ctx.createMediaStreamDestination) {
          var md = ctx.createMediaStreamDestination();
          origConnect.call(g, md);
          ctx.__tagTap = md;
        }
      } catch (e) {}
      ctx.__tagOut = g;
      audioContexts.push(ctx);
      if (guestMode) g.gain.value = 0;
      return g;
    }
    AudioNode.prototype.connect = function (dest) {
      if (dest instanceof AudioDestinationNode && this.context === dest.context && this !== dest.context.__tagOut) {
        var out = ensureOut(dest.context);
        var rest = Array.prototype.slice.call(arguments, 1);
        origConnect.apply(this, [out].concat(rest));
        return dest;
      }
      return origConnect.apply(this, arguments);
    };
    AudioNode.prototype.disconnect = function (dest) {
      if (dest instanceof AudioDestinationNode && dest.context.__tagOut) {
        var rest = Array.prototype.slice.call(arguments, 1);
        return origDisconnect.apply(this, [dest.context.__tagOut].concat(rest));
      }
      return origDisconnect.apply(this, arguments);
    };
  })();
  function setLocalMute(mute) {
    audioContexts.forEach(function (c) { try { c.__tagOut.gain.value = mute ? 0 : 1; } catch (e) {} });
  }

  // --------------------------------------------------------- virtual keyboard
  // [code, key, keyCode] per action, per player slot (matches the game's own bindings).
  var SLOT_KEYS = {
    1: { l: ['KeyA', 'a', 65], u: ['KeyW', 'w', 87], r: ['KeyD', 'd', 68], a: ['KeyQ', 'q', 81] },
    2: { l: ['ArrowLeft', 'ArrowLeft', 37], u: ['ArrowUp', 'ArrowUp', 38], r: ['ArrowRight', 'ArrowRight', 39], a: ['KeyC', 'c', 67] },
    3: { l: ['KeyJ', 'j', 74], u: ['KeyI', 'i', 73], r: ['KeyL', 'l', 76], a: ['KeyY', 'y', 89] },
    4: { l: ['KeyF', 'f', 70], u: ['KeyT', 't', 84], r: ['KeyH', 'h', 72], a: ['KeyM', 'm', 77] }
  };
  var KEY_ESC = ['Escape', 'Escape', 27];
  var vDown = {};
  function fireKey(k, down) {
    var ev = new KeyboardEvent(down ? 'keydown' : 'keyup', {
      code: k[0], key: k[1], keyCode: k[2], which: k[2], bubbles: true, cancelable: true
    });
    try {
      Object.defineProperty(ev, 'which', { value: k[2] });
      Object.defineProperty(ev, 'keyCode', { value: k[2] });
    } catch (e) {}
    window.dispatchEvent(ev);
  }
  function sendKey(k, down) {
    if (!!vDown[k[0]] === down) return;
    vDown[k[0]] = down;
    fireKey(k, down);
  }
  // Construct clears its key state when the window loses focus; forget ours too
  // so held virtual keys get re-sent afterwards.
  window.addEventListener('blur', function () { vDown = {}; });

  var BIT_L = 1, BIT_R = 2, BIT_J = 4;
  function controlMode() {
    try { return runtime ? runtime.globalVars.pc_control : undefined; } catch (e) { return undefined; }
  }
  function applySlot(s, bits) {
    var K = SLOT_KEYS[s];
    var jump = !!(bits & BIT_J);
    var mode = controlMode();
    if (mode === 1) {            // the game's one-button mode: a single key per player
      sendKey(K.l, false); sendKey(K.r, false); sendKey(K.u, false);
      sendKey(K.a, jump);
    } else {                     // three-key mode (default)
      sendKey(K.l, !!(bits & BIT_L));
      sendKey(K.r, !!(bits & BIT_R));
      sendKey(K.u, jump);
      sendKey(K.a, false);
    }
  }

  // ----------------------------------------------------------------- gamepads
  var padSlot = {};            // pad index -> slot (0 = unassigned)
  var padStart = {};           // pad index -> was start pressed
  function getPads() {
    try {
      var list = navigator.getGamepads ? navigator.getGamepads() : [];
      var out = [];
      for (var i = 0; i < list.length; i++) if (list[i] && list[i].connected !== false) out.push(list[i]);
      return out;
    } catch (e) { return []; }
  }
  function btn(gp, i) { var b = gp.buttons && gp.buttons[i]; return !!b && (b.pressed || b.value > 0.5); }
  function readPad(gp) {
    var std = gp.mapping === 'standard';
    var x = (gp.axes && gp.axes[0]) || 0, y = (gp.axes && gp.axes[1]) || 0;
    var bits = 0;
    if (x < -0.4 || (std && btn(gp, 14))) bits |= BIT_L;
    if (x > 0.4 || (std && btn(gp, 15))) bits |= BIT_R;
    var j = y < -0.7;
    if (std) { for (var i = 0; i < 8; i++) if (btn(gp, i)) j = true; if (btn(gp, 12)) j = true; }   // face buttons, shoulders, triggers, d-pad up
    else { for (var n = 0; n < 4; n++) if (btn(gp, n)) j = true; }
    if (j) bits |= BIT_J;
    return { bits: bits, start: btn(gp, 9) };
  }
  function usedSlots() {
    var used = {};
    for (var i in padSlot) if (padSlot[i]) used[padSlot[i]] = true;
    if (hosting) hosting.guests.forEach(function (g) { if (g.slot) used[g.slot] = true; });
    return used;
  }
  function firstFreeSlot(from) {
    var used = usedSlots();
    for (var s = from || 1; s <= 4; s++) if (!used[s]) return s;
    for (var t = 1; t <= 4; t++) if (!used[t]) return t;
    return 0;
  }
  window.addEventListener('gamepadconnected', function (e) {
    if (guestMode) return;
    if (padSlot[e.gamepad.index] === undefined) padSlot[e.gamepad.index] = firstFreeSlot(1);
    toast('Controller connected' + (padSlot[e.gamepad.index] ? ' — Player ' + padSlot[e.gamepad.index] : ''));
    refreshControllers();
  });
  window.addEventListener('gamepaddisconnected', function (e) {
    delete padSlot[e.gamepad.index]; delete padStart[e.gamepad.index];
    toast('Controller disconnected');
    refreshControllers();
  });

  function tapEsc() { fireKey(KEY_ESC, true); setTimeout(function () { fireKey(KEY_ESC, false); }, 60); }

  // ---------------------------------------------------- the per-frame input loop
  var lastSend = { bits: -1, t: 0 };
  var guestKeys = {};
  function guestKeyBits() {
    var b = 0;
    if (guestKeys.KeyA || guestKeys.ArrowLeft) b |= BIT_L;
    if (guestKeys.KeyD || guestKeys.ArrowRight) b |= BIT_R;
    if (guestKeys.KeyW || guestKeys.ArrowUp || guestKeys.Space) b |= BIT_J;
    return b;
  }
  function frame() {
    requestAnimationFrame(frame);
    var pads = getPads();
    if (guestMode) {
      var gb = guestKeyBits();
      for (var i = 0; i < pads.length; i++) gb |= readPad(pads[i]).bits;
      var now = performance.now();
      if (guest && guest.conn && guest.open && (gb !== lastSend.bits || now - lastSend.t > 250)) {
        try { guest.conn.send({ t: 'in', b: gb }); } catch (e) {}
        lastSend.bits = gb; lastSend.t = now;
      }
      return;
    }
    var bits = [0, 0, 0, 0, 0];
    for (var p = 0; p < pads.length; p++) {
      var gp = pads[p];
      if (padSlot[gp.index] === undefined) padSlot[gp.index] = firstFreeSlot(1);
      var slot = padSlot[gp.index];
      var r = readPad(gp);
      if (slot) bits[slot] |= r.bits;
      if (r.start && !padStart[gp.index]) tapEsc();
      padStart[gp.index] = r.start;
    }
    if (hosting) {
      var nowT = performance.now();
      hosting.guests.forEach(function (g) {
        if (nowT - g.seen > 8000) { dropGuest(g, 'timed out'); return; }
        if (g.slot) bits[g.slot] |= g.bits;
      });
    }
    for (var s = 1; s <= 4; s++) applySlot(s, bits[s]);
  }

  // -------------------------------------------------------------- handicaps
  var TAGGER_BOOST = [0, 0.08, 0.15, 0.25];
  var LEADER_SLOW = [0, 0.05, 0.10, 0.15];
  var LEADER_MARGIN = 3;       // seconds less "it" time than everyone else
  var hc = { states: new WeakMap(), tagTime: [0, 0, 0, 0, 0], layout: '', leader: 0, tagger: 0, active: {} };
  function hcTick() {
    var rt = runtime;
    if (!rt) return;
    var gv = rt.globalVars, name = '';
    try { name = rt.layout.name; } catch (e) {}
    if (name !== hc.layout) { hc.layout = name; hc.tagTime = [0, 0, 0, 0, 0]; }
    var inMap = /^map\d/.test(name);
    var voda = inMap ? (gv.voda | 0) : 0;
    var players = Math.max(2, Math.min(4, gv.playersCount | 0 || 2));
    if (inMap && voda >= 1 && voda <= 4 && gv.timer > 0) hc.tagTime[voda] += rt.dt;

    var leader = 0;
    if (inMap && players >= 2) {
      var min = Infinity, minSlot = 0, second = Infinity;
      for (var s = 1; s <= players; s++) {
        var v = hc.tagTime[s];
        if (v < min) { second = min; min = v; minSlot = s; }
        else if (v < second) second = v;
      }
      if (second - min >= LEADER_MARGIN) leader = minSlot;
    }
    hc.leader = leader; hc.tagger = voda;

    var mode = cfg.hcMode, lvl = cfg.hcLevel | 0;
    var useTag = inMap && (mode === 'tagger' || mode === 'both');
    var useLead = inMap && (mode === 'leader' || mode === 'both');
    hc.active = {};
    for (var slot = 1; slot <= 4; slot++) {
      var mult = 1;
      if (useTag && slot === voda) mult *= 1 + TAGGER_BOOST[lvl];
      if (useLead && slot === leader) mult *= 1 - LEADER_SLOW[lvl];
      if (mult !== 1) hc.active[slot] = mult;
      var type = rt.objects['p' + slot];
      if (!type) continue;
      var insts = type.getAllInstances();
      for (var i = 0; i < insts.length; i++) {
        var inst = insts[i];
        if (inst.instVars && inst.instVars.isDecoy === 1) continue;   // leave decoys alone
        var beh = inst.behaviors && inst.behaviors.Platform;
        if (!beh) continue;
        var cur = beh.maxSpeed, st = hc.states.get(inst);
        if (!st) { st = { base: cur, last: cur }; hc.states.set(inst, st); }
        else if (Math.abs(cur - st.last) > 0.01) { st.base = cur; st.last = cur; } // the game changed it (speed buff on/off)
        var want = st.base * mult;
        if (Math.abs(want - cur) > 0.01) { beh.maxSpeed = want; st.last = want; }
      }
    }
  }

  // ---------------------------------------------------------------- online
  var hosting = null;   // { peer, code, guests: Map, stream, mirror, timer }
  var guest = null;     // { peer, conn, open, slot, ping, video }
  var onlineState = { phase: 'idle', msg: '' };   // idle | starting | hosting | joining | guest

  function loadPeerLib() {
    return new Promise(function (resolve, reject) {
      var P = window.peerjs && window.peerjs.Peer || window.Peer;
      if (P) return resolve(P);
      var s = document.createElement('script');
      s.src = 'scripts/peerjs.min.js';
      s.onload = function () {
        var Q = window.peerjs && window.peerjs.Peer || window.Peer;
        Q ? resolve(Q) : reject(new Error('Networking library failed to start'));
      };
      s.onerror = function () { reject(new Error('Could not load the networking library')); };
      document.head.appendChild(s);
    });
  }
  function openPeer(Peer, id) {
    return new Promise(function (resolve, reject) {
      var p = id ? new Peer(id, netConfig()) : new Peer(netConfig());
      var done = false;
      p.on('open', function () { done = true; resolve(p); });
      p.on('error', function (e) { if (!done) { done = true; try { p.destroy(); } catch (x) {} reject(e); } });
      setTimeout(function () { if (!done) { done = true; try { p.destroy(); } catch (x) {} reject({ type: 'timeout' }); } }, 15000);
    });
  }
  function friendlyError(e) {
    var t = e && e.type;
    if (t === 'peer-unavailable') return 'No game found with that code. Check it and try again.';
    if (t === 'unavailable-id') return 'That room code is already taken.';
    if (t === 'timeout') return 'Could not reach the matchmaking server. Check your internet connection.';
    if (t === 'network' || t === 'server-error' || t === 'socket-error' || t === 'socket-closed')
      return 'Could not reach the matchmaking server. Check your internet connection.';
    if (t === 'browser-incompatible') return 'This browser does not support online play.';
    return (e && e.message) || 'Something went wrong with the connection.';
  }
  function makeCode() {
    var s = '';
    var arr = new Uint32Array(5);
    (window.crypto || window.msCrypto).getRandomValues(arr);
    for (var i = 0; i < 5; i++) s += ROOM_ALPHABET[arr[i] % ROOM_ALPHABET.length];
    return s;
  }

  // ---- host
  function getHostStream() {
    if (hosting.stream) return hosting.stream;
    var src = window.c3canvas;
    var mirror = document.createElement('canvas');
    var mctx = mirror.getContext('2d', { alpha: false });
    function draw() {
      var sw = src.width, sh = src.height;
      if (!sw || !sh) return;
      var sc = Math.min(1, 1280 / sw);
      var w = Math.max(2, Math.round(sw * sc)), h = Math.max(2, Math.round(sh * sc));
      if (mirror.width !== w || mirror.height !== h) { mirror.width = w; mirror.height = h; }
      try { mctx.drawImage(src, 0, 0, w, h); } catch (e) {}
    }
    draw();
    hosting.timer = setInterval(draw, 1000 / 30);
    var tracks = mirror.captureStream(30).getVideoTracks();
    for (var i = 0; i < audioContexts.length; i++) {
      var tap = audioContexts[i].__tagTap;
      if (tap && tap.stream.getAudioTracks().length) { tracks.push(tap.stream.getAudioTracks()[0]); break; }
    }
    hosting.stream = new MediaStream(tracks);
    return hosting.stream;
  }
  function tuneSender(call) {
    try {
      var pc = call.peerConnection;
      pc.getSenders().forEach(function (s) {
        if (s.track && s.track.kind === 'video') {
          var p = s.getParameters();
          if (!p.encodings || !p.encodings.length) p.encodings = [{}];
          p.encodings[0].maxBitrate = 3000000;
          p.degradationPreference = 'maintain-framerate';
          s.setParameters(p);
        }
      });
    } catch (e) {}
  }
  async function startHosting() {
    if (onlineState.phase !== 'idle') return;
    setOnline('starting', 'Creating a room…');
    try {
      var Peer = await loadPeerLib();
      var peer = null, code = '';
      for (var attempt = 0; attempt < 6 && !peer; attempt++) {
        code = makeCode();
        try { peer = await openPeer(Peer, ROOM_PREFIX + code); }
        catch (e) { if (!e || e.type !== 'unavailable-id') throw e; }
      }
      if (!peer) throw { type: 'unavailable-id' };
      hosting = { peer: peer, code: code, guests: new Map(), stream: null, mirror: null, timer: 0, n: 0 };
      peer.on('connection', onGuestConn);
      peer.on('disconnected', function () { try { peer.reconnect(); } catch (e) {} });
      peer.on('error', function (e) { toast(friendlyError(e)); });
      setOnline('hosting', '');
    } catch (e) {
      hosting = null;
      setOnline('idle', friendlyError(e));
    }
  }
  function onGuestConn(conn) {
    var g = { id: conn.peer, conn: conn, slot: 0, bits: 0, seen: performance.now(), ping: 0, label: '' };
    var admitted = false;
    conn.on('open', function () {
      if (!hosting) return conn.close();
      if (hosting.guests.size >= MAX_GUESTS) {
        try { conn.send({ t: 'full' }); } catch (e) {}
        setTimeout(function () { try { conn.close(); } catch (e) {} }, 400);
        return;
      }
      admitted = true;
      g.label = 'Guest ' + (++hosting.n);
      g.slot = firstFreeSlot(2);
      hosting.guests.set(g.id, g);
      try { conn.send({ t: 'welcome', slot: g.slot, v: VERSION }); } catch (e) {}
      try {
        g.call = hosting.peer.call(g.id, getHostStream());
        setTimeout(function () { tuneSender(g.call); }, 1500);
      } catch (e) { toast('Could not start video for ' + g.label); }
      toast(g.label + ' joined' + (g.slot ? ' as Player ' + g.slot : ' as a spectator'));
      refreshOnline();
    });
    conn.on('data', function (m) {
      if (!m || typeof m !== 'object') return;
      g.seen = performance.now();
      if (m.t === 'in') g.bits = m.b & 7;
      else if (m.t === 'p') { try { conn.send({ t: 'pong', ts: m.ts, rtt: g.ping }); } catch (e) {} }
      else if (m.t === 'rtt') g.ping = m.v | 0;
      else if (m.t === 'bye') dropGuest(g, 'left');
    });
    conn.on('close', function () { if (admitted) dropGuest(g, 'left'); });
    conn.on('error', function () { if (admitted) dropGuest(g, 'lost'); });
  }
  function dropGuest(g, why) {
    if (!hosting || !hosting.guests.has(g.id)) return;
    hosting.guests.delete(g.id);
    try { g.call && g.call.close(); } catch (e) {}
    try { g.conn.close(); } catch (e) {}
    toast(g.label + ' ' + (why || 'left'));
    refreshOnline();
  }
  function setGuestSlot(id, slot) {
    var g = hosting && hosting.guests.get(id);
    if (!g) return;
    g.slot = slot;
    try { g.conn.send({ t: 'slot', slot: slot }); } catch (e) {}
    refreshOnline();
  }
  function stopHosting() {
    if (!hosting) return;
    var h = hosting; hosting = null;
    h.guests.forEach(function (g) {
      try { g.conn.send({ t: 'closed' }); } catch (e) {}
      try { g.call && g.call.close(); } catch (e) {}
    });
    setTimeout(function () { try { h.peer.destroy(); } catch (e) {} }, 200);
    clearInterval(h.timer);
    if (h.stream) h.stream.getVideoTracks().forEach(function (t) { t.stop(); });
    setOnline('idle', '');
  }

  // ---- guest
  async function joinGame(rawCode) {
    var code = String(rawCode || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (code.length < 4) { setOnline('idle', 'Enter the room code your friend is showing.'); return; }
    if (onlineState.phase !== 'idle') return;
    setOnline('joining', 'Connecting…');
    var peer = null;
    try {
      var Peer = await loadPeerLib();
      peer = await openPeer(Peer, null);
      var g = guest = { peer: peer, conn: null, open: false, slot: 0, ping: 0, video: null, code: code };
      var failed = false;
      function fail(e) {
        if (failed) return; failed = true;
        leaveGame(friendlyError(e));
      }
      peer.on('error', function (e) { if (guest === g) fail(e); });
      peer.on('call', function (call) {
        call.answer();
        call.on('stream', function (stream) { showGuestVideo(stream); });
      });
      var conn = g.conn = peer.connect(ROOM_PREFIX + code, { reliable: true });
      var t = setTimeout(function () { if (!g.open) fail({ type: 'timeout' }); }, 12000);
      conn.on('open', function () {
        clearTimeout(t);
        g.open = true;
        conn.send({ t: 'hello', v: VERSION });
        enterGuestMode();
        g.pingTimer = setInterval(function () {
          try { conn.send({ t: 'p', ts: performance.now() }); } catch (e) {}
        }, 2000);
      });
      conn.on('data', function (m) {
        if (!m || typeof m !== 'object') return;
        if (m.t === 'welcome' || m.t === 'slot') { g.slot = m.slot; updateGuestHud(); }
        else if (m.t === 'pong') {
          g.ping = Math.round(performance.now() - m.ts); updateGuestHud();
          try { conn.send({ t: 'rtt', v: g.ping }); } catch (e) {}
        }
        else if (m.t === 'full') leaveGame('That game is full (host + 3 friends max).');
        else if (m.t === 'closed') leaveGame('The host ended the game.');
      });
      conn.on('close', function () { if (guest === g && g.open) leaveGame('Disconnected from the host.'); });
      conn.on('error', function (e) { if (guest === g) fail(e); });
    } catch (e) {
      if (peer) try { peer.destroy(); } catch (x) {}
      guest = null;
      setOnline('idle', friendlyError(e));
    }
  }
  function leaveGame(msg) {
    var g = guest; guest = null;
    if (g) {
      try { g.conn && g.open && g.conn.send({ t: 'bye' }); } catch (e) {}
      clearInterval(g.pingTimer);
      setTimeout(function () { try { g.peer.destroy(); } catch (e) {} }, 150);
    }
    exitGuestMode();
    setOnline('idle', msg || '');
  }
  var guestEls = null;
  function enterGuestMode() {
    guestMode = true;
    setLocalMute(true);
    lastSend.bits = -1;
    for (var s = 1; s <= 4; s++) applySlot(s, 0);   // release anything we were holding
    var root = el('div', 'tm-guest');
    root.innerHTML =
      '<video class="tm-gvideo" autoplay playsinline></video>' +
      '<div class="tm-gwait">Waiting for the host’s video…</div>' +
      '<div class="tm-ghud"><span class="tm-gchip"></span><span class="tm-gping"></span>' +
      '<button class="tm-gleave" type="button">Leave</button></div>' +
      '<div class="tm-ghint">Move: A / D or ← → &nbsp;·&nbsp; Jump: W, ↑ or Space &nbsp;·&nbsp; or use a gamepad</div>';
    document.body.appendChild(root);
    stopProp(root);
    guestEls = {
      root: root, video: root.querySelector('video'), wait: root.querySelector('.tm-gwait'),
      chip: root.querySelector('.tm-gchip'), ping: root.querySelector('.tm-gping'), hint: root.querySelector('.tm-ghint')
    };
    root.querySelector('.tm-gleave').addEventListener('click', function () { leaveGame(''); });
    setTimeout(function () { if (guestEls) guestEls.hint.style.opacity = '0'; }, 9000);
    document.getElementById('tm-fab').style.display = 'none';
    closePanel();
    updateGuestHud();
    setOnline('guest', '');
  }
  function exitGuestMode() {
    if (!guestMode) return;
    guestMode = false;
    guestKeys = {};
    setLocalMute(false);
    if (guestEls) {
      try { guestEls.video.srcObject = null; } catch (e) {}
      guestEls.root.remove(); guestEls = null;
    }
    var fab = document.getElementById('tm-fab'); if (fab) fab.style.display = '';
  }
  function showGuestVideo(stream) {
    if (!guestEls) return;
    var v = guestEls.video;
    v.srcObject = stream;
    v.muted = false;
    var pr = v.play();
    if (pr && pr.catch) pr.catch(function () {
      v.muted = true; v.play().catch(function () {});
      guestEls.wait.textContent = 'Click anywhere to turn on sound';
      guestEls.wait.style.display = '';
      guestEls.root.addEventListener('click', function once() {
        v.muted = false; guestEls && (guestEls.wait.style.display = 'none');
        guestEls && guestEls.root.removeEventListener('click', once);
      });
    });
    v.addEventListener('playing', function () { if (guestEls) guestEls.wait.style.display = 'none'; });
  }
  function updateGuestHud() {
    if (!guestEls || !guest) return;
    guestEls.chip.textContent = guest.slot ? 'You are Player ' + guest.slot : 'Spectating';
    guestEls.chip.style.background = guest.slot ? SLOT_COLORS[guest.slot] : '#555';
    guestEls.ping.textContent = guest.ping ? guest.ping + ' ms' : '';
  }
  // keyboard capture for guests (capture phase, so the local game never sees it)
  function guestKeyHandler(down) {
    return function (e) {
      if (!guestMode) return;
      var t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
      if (e.__tagSynthetic) return;
      if (e.code === 'KeyA' || e.code === 'KeyD' || e.code === 'KeyW' || e.code === 'ArrowLeft' ||
          e.code === 'ArrowRight' || e.code === 'ArrowUp' || e.code === 'Space') {
        guestKeys[e.code] = down;
        e.preventDefault();
      }
    };
  }
  window.addEventListener('keydown', guestKeyHandler(true), true);
  window.addEventListener('keyup', guestKeyHandler(false), true);

  // ------------------------------------------------------------------- UI
  var SLOT_COLORS = { 1: '#e8453c', 2: '#2f7cf6', 3: '#f2b81c', 4: '#34b24a' };
  var panel = null, panelOpen = false, activeTab = 'controllers', toastTimer = 0;

  function el(tag, cls) { var e = document.createElement(tag); if (cls) e.className = cls; return e; }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); }
  // Keep UI clicks/keys from reaching the game's window-level listeners.
  function stopProp(node) {
    ['pointerdown', 'pointerup', 'pointermove', 'mousedown', 'mouseup', 'click', 'dblclick', 'touchstart', 'touchend', 'touchmove', 'wheel', 'keydown', 'keyup', 'contextmenu']
      .forEach(function (n) { node.addEventListener(n, function (e) { e.stopPropagation(); }); });
  }
  function toast(msg) {
    if (!document.body) return;
    var t = document.getElementById('tm-toast');
    if (!t) { t = el('div'); t.id = 'tm-toast'; document.body.appendChild(t); }
    t.textContent = msg; t.style.opacity = '1';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.style.opacity = '0'; }, 3200);
  }
  function slotSelect(cur, attr, withOff) {
    var h = '<select class="tm-sel" ' + attr + '>';
    h += '<option value="0"' + (cur === 0 ? ' selected' : '') + '>' + (withOff || 'Off') + '</option>';
    for (var s = 1; s <= 4; s++) h += '<option value="' + s + '"' + (cur === s ? ' selected' : '') + '>Player ' + s + '</option>';
    return h + '</select>';
  }

  var CSS =
    '#tm-fab{position:fixed;right:14px;bottom:14px;width:42px;height:42px;border-radius:50%;border:1px solid rgba(255,255,255,.25);' +
    'background:rgba(20,22,30,.62);color:#fff;font:20px/40px system-ui,sans-serif;text-align:center;cursor:pointer;z-index:2147483000;' +
    'opacity:.45;transition:opacity .15s,transform .15s;padding:0;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}' +
    '#tm-fab:hover,#tm-fab.on{opacity:1;transform:scale(1.06)}' +
    '#tm-panel{position:fixed;right:14px;bottom:66px;width:340px;max-width:calc(100vw - 28px);max-height:calc(100vh - 90px);overflow:auto;' +
    'background:rgba(18,20,28,.94);color:#eef0f6;border:1px solid rgba(255,255,255,.14);border-radius:14px;z-index:2147483001;' +
    'font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;box-shadow:0 12px 40px rgba(0,0,0,.5);display:none;' +
    'backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);user-select:none;-webkit-user-select:none}' +
    '#tm-panel.open{display:block}' +
    '.tm-tabs{display:flex;border-bottom:1px solid rgba(255,255,255,.1);position:sticky;top:0;background:rgba(18,20,28,.97);border-radius:14px 14px 0 0}' +
    '.tm-tab{flex:1;padding:11px 6px;text-align:center;cursor:pointer;color:#9aa0b4;font-weight:600;font-size:13px;border:0;background:none;' +
    'border-bottom:2px solid transparent;font-family:inherit}' +
    '.tm-tab.on{color:#fff;border-bottom-color:#5aa9ff}' +
    '.tm-body{padding:14px 16px 16px}' +
    '.tm-body h4{margin:0 0 6px;font-size:13px;letter-spacing:.02em;color:#c9cde0}' +
    '.tm-body p{margin:0 0 10px;color:#aab0c4;font-size:13px}' +
    '.tm-row{display:flex;align-items:center;gap:8px;margin:7px 0}' +
    '.tm-row .grow{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.tm-sel,.tm-input{background:#262a3a;color:#fff;border:1px solid rgba(255,255,255,.18);border-radius:8px;padding:6px 8px;font:inherit;font-size:13px}' +
    '.tm-input{width:100%;box-sizing:border-box;letter-spacing:.18em;text-transform:uppercase;font-weight:700;font-size:18px;text-align:center;padding:9px}' +
    '.tm-btn{background:#3b82f6;color:#fff;border:0;border-radius:9px;padding:9px 14px;font:inherit;font-weight:700;font-size:13px;cursor:pointer}' +
    '.tm-btn:hover{filter:brightness(1.1)}.tm-btn.sec{background:#2d3246}.tm-btn.bad{background:#b83b3b}.tm-btn.full{width:100%}' +
    '.tm-btn[disabled]{opacity:.5;cursor:default}' +
    '.tm-seg{display:flex;gap:0;margin:6px 0 4px}' +
    '.tm-seg button{flex:1;padding:8px 4px;background:#262a3a;color:#c6cadb;border:1px solid rgba(255,255,255,.14);font:inherit;font-size:13px;cursor:pointer}' +
    '.tm-seg button:first-child{border-radius:8px 0 0 8px}.tm-seg button:last-child{border-radius:0 8px 8px 0}' +
    '.tm-seg button.on{background:#3b82f6;color:#fff;border-color:#3b82f6}' +
    '.tm-chip{display:inline-block;min-width:24px;padding:1px 8px;border-radius:20px;font-weight:700;font-size:12px;color:#111;text-align:center}' +
    '.tm-code{font:800 40px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.16em;text-align:center;margin:8px 0 4px;color:#fff;user-select:text;-webkit-user-select:text}' +
    '.tm-muted{color:#8d93a8;font-size:12px}' +
    '.tm-err{color:#ff9b9b;font-size:13px;margin:8px 0}' +
    '.tm-keys{width:100%;border-collapse:collapse;font-size:12px;margin-top:4px}' +
    '.tm-keys td{padding:3px 4px;border-bottom:1px solid rgba(255,255,255,.07)}' +
    '.tm-keys td:first-child{width:64px}' +
    '.tm-live{font-size:12px;color:#7fe0a0;margin-top:8px;min-height:16px}' +
    '#tm-toast{position:fixed;top:16px;left:50%;transform:translateX(-50%);background:rgba(18,20,28,.92);color:#fff;padding:9px 16px;border-radius:20px;' +
    'font:600 13px system-ui,sans-serif;z-index:2147483002;opacity:0;transition:opacity .25s;pointer-events:none;border:1px solid rgba(255,255,255,.15)}' +
    '.tm-guest{position:fixed;inset:0;background:#000;z-index:2147483003;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif;color:#fff}' +
    '.tm-gvideo{width:100%;height:100%;object-fit:contain;background:#000}' +
    '.tm-gwait{position:absolute;font-size:16px;color:#cfd3e4}' +
    '.tm-ghud{position:absolute;top:12px;right:12px;display:flex;gap:8px;align-items:center}' +
    '.tm-gchip{padding:5px 12px;border-radius:20px;font-weight:700;font-size:13px;color:#111}' +
    '.tm-gping{font-size:12px;color:#c9cde0;min-width:42px}' +
    '.tm-gleave{background:rgba(20,22,30,.75);color:#fff;border:1px solid rgba(255,255,255,.25);border-radius:9px;padding:6px 12px;font:600 13px system-ui;cursor:pointer}' +
    '.tm-ghint{position:absolute;bottom:18px;left:50%;transform:translateX(-50%);background:rgba(20,22,30,.78);padding:8px 14px;border-radius:20px;font-size:13px;transition:opacity 1s;white-space:nowrap;max-width:94vw;overflow:hidden;text-overflow:ellipsis}';

  function buildUI() {
    if (document.getElementById('tm-fab')) return;
    var style = el('style'); style.textContent = CSS; document.head.appendChild(style);
    var fab = el('button'); fab.id = 'tm-fab'; fab.type = 'button'; fab.title = 'Gamepads, handicaps & online play (F2)';
    fab.textContent = '🎮';
    document.body.appendChild(fab); stopProp(fab);
    fab.addEventListener('click', togglePanel);

    panel = el('div'); panel.id = 'tm-panel';
    panel.innerHTML =
      '<div class="tm-tabs">' +
      '<button class="tm-tab" data-tab="controllers" type="button">Controllers</button>' +
      '<button class="tm-tab" data-tab="handicap" type="button">Handicap</button>' +
      '<button class="tm-tab" data-tab="online" type="button">Online</button></div>' +
      '<div class="tm-body" id="tm-body"></div>';
    document.body.appendChild(panel); stopProp(panel);
    panel.addEventListener('click', onPanelClick);
    panel.addEventListener('change', onPanelChange);
    panel.addEventListener('input', function (e) {
      if (e.target && e.target.id === 'tm-joincode') {
        var v = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (v !== e.target.value) e.target.value = v;
        joinDraft = v;
      }
    });
    panel.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target && e.target.id === 'tm-joincode') joinGame(joinDraft);
    });
    window.addEventListener('keydown', function (e) {
      if (e.key === 'F2') { e.preventDefault(); togglePanel(); }
    }, true);
    setInterval(function () { if (panelOpen && activeTab === 'handicap') refreshLive(); }, 400);

    if (!cfg.hintSeen) {
      cfg.hintSeen = true; saveCfg();
      setTimeout(function () { toast('Gamepads, handicaps & online play: press F2 or click 🎮'); }, 2500);
    }
  }
  var joinDraft = '';
  function togglePanel() { panelOpen ? closePanel() : openPanel(); }
  function openPanel() { if (guestMode || !panel) return; panelOpen = true; panel.classList.add('open'); document.getElementById('tm-fab').classList.add('on'); render(); }
  function closePanel() { panelOpen = false; if (panel) panel.classList.remove('open'); var f = document.getElementById('tm-fab'); if (f) f.classList.remove('on'); }

  function render() {
    if (!panel) return;
    Array.prototype.forEach.call(panel.querySelectorAll('.tm-tab'), function (t) { t.classList.toggle('on', t.getAttribute('data-tab') === activeTab); });
    var body = document.getElementById('tm-body');
    if (activeTab === 'controllers') body.innerHTML = controllersHTML();
    else if (activeTab === 'handicap') { body.innerHTML = handicapHTML(); refreshLive(); }
    else body.innerHTML = onlineHTML();
  }
  function refreshControllers() { if (panelOpen && activeTab === 'controllers') render(); }
  function refreshOnline() { if (panelOpen && activeTab === 'online') render(); }
  function setOnline(phase, msg) { onlineState.phase = phase; onlineState.msg = msg || ''; refreshOnline(); }

  function controllersHTML() {
    var pads = getPads();
    var h = '<h4>Gamepads</h4>';
    if (!pads.length) {
      h += '<p>No controller detected. Plug one in (or pair it by Bluetooth) and press any button.</p>';
    } else {
      h += '<p>Each controller drives one player. Left stick or D-pad to move, any face button or shoulder to jump, Start to pause.</p>';
      pads.forEach(function (gp) {
        var s = padSlot[gp.index] | 0;
        h += '<div class="tm-row"><span class="tm-chip" style="background:' + (SLOT_COLORS[s] || '#666') + '">' + (s ? 'P' + s : '–') + '</span>' +
          '<span class="grow" title="' + esc(gp.id) + '">' + esc(gp.id.replace(/\s*\(.*$/, '') || 'Controller') + '</span>' +
          slotSelect(s, 'data-pad="' + gp.index + '"') + '</div>';
      });
    }
    h += '<h4 style="margin-top:14px">Keyboard players</h4><table class="tm-keys">' +
      '<tr><td><span class="tm-chip" style="background:' + SLOT_COLORS[1] + '">P1</span></td><td>A &nbsp; W &nbsp; D</td></tr>' +
      '<tr><td><span class="tm-chip" style="background:' + SLOT_COLORS[2] + '">P2</span></td><td>← &nbsp; ↑ &nbsp; →</td></tr>' +
      '<tr><td><span class="tm-chip" style="background:' + SLOT_COLORS[3] + '">P3</span></td><td>J &nbsp; I &nbsp; L</td></tr>' +
      '<tr><td><span class="tm-chip" style="background:' + SLOT_COLORS[4] + '">P4</span></td><td>F &nbsp; T &nbsp; H</td></tr></table>' +
      '<p class="tm-muted" style="margin-top:8px">Controllers and keyboards can be mixed. Menus are still clicked with the mouse.</p>';
    return h;
  }
  function handicapHTML() {
    var m = cfg.hcMode, l = cfg.hcLevel | 0;
    function seg(group, items, cur) {
      return '<div class="tm-seg">' + items.map(function (it) {
        return '<button type="button" data-' + group + '="' + it[0] + '" class="' + (String(cur) === String(it[0]) ? 'on' : '') + '">' + it[1] + '</button>';
      }).join('') + '</div>';
    }
    return '<h4>Handicap</h4><p>Keeps mixed-skill groups competitive by nudging running speed.</p>' +
      seg('hcmode', [['off', 'Off'], ['tagger', 'Tagger boost'], ['leader', 'Leader slow'], ['both', 'Both']], m) +
      '<p class="tm-muted">' +
      '<b>Tagger boost</b> — whoever is “it” runs a bit faster.<br>' +
      '<b>Leader slow</b> — the player who has been “it” least (by ' + LEADER_MARGIN + '+ seconds) runs a bit slower.</p>' +
      '<h4 style="margin-top:12px">Strength</h4>' +
      seg('hclvl', [[1, 'Light'], [2, 'Medium'], [3, 'Strong']], l) +
      '<p class="tm-muted">Light: +8% / −5% &nbsp; Medium: +15% / −10% &nbsp; Strong: +25% / −15%</p>' +
      '<div class="tm-live" id="tm-live"></div>';
  }
  function refreshLive() {
    var live = document.getElementById('tm-live'); if (!live) return;
    var parts = [];
    for (var s in hc.active) parts.push('P' + s + ' ' + (hc.active[s] > 1 ? '+' : '') + Math.round((hc.active[s] - 1) * 100) + '%');
    live.textContent = cfg.hcMode === 'off' ? '' : (parts.length ? 'Right now: ' + parts.join(', ') : 'Active during a match.');
  }
  function onlineHTML() {
    var st = onlineState.phase, msg = onlineState.msg;
    var err = msg && st === 'idle' ? '<div class="tm-err">' + esc(msg) + '</div>' : '';
    if (st === 'idle') {
      return '<h4>Play with friends online</h4>' +
        '<p>One person hosts and shares a 5-letter code. Friends join from their own computer and see the game live, with their own controls.</p>' +
        '<button class="tm-btn full" data-act="host" type="button">Host a game</button>' +
        '<div class="tm-muted" style="text-align:center;margin:12px 0 6px">— or join a friend —</div>' +
        '<input id="tm-joincode" class="tm-input" maxlength="8" placeholder="CODE" autocomplete="off" spellcheck="false" value="' + esc(joinDraft) + '">' +
        '<div style="margin-top:8px"><button class="tm-btn sec full" data-act="join" type="button">Join game</button></div>' + err +
        '<p class="tm-muted" style="margin-top:12px">Needs an internet connection. The host’s computer runs the game, so the host should pick the map and player count.</p>';
    }
    if (st === 'starting' || st === 'joining') return '<h4>' + (st === 'starting' ? 'Creating room…' : 'Joining…') + '</h4><p>' + esc(msg) + '</p>';
    if (st === 'hosting' && hosting) {
      var h = '<h4>Your room code</h4><div class="tm-code">' + esc(hosting.code) + '</div>' +
        '<div class="tm-row" style="justify-content:center"><button class="tm-btn sec" data-act="copy" type="button">Copy code</button></div>' +
        '<h4 style="margin-top:14px">Players online (' + hosting.guests.size + '/' + MAX_GUESTS + ')</h4>';
      if (!hosting.guests.size) h += '<p class="tm-muted">Waiting for friends to join…</p>';
      hosting.guests.forEach(function (g) {
        h += '<div class="tm-row"><span class="tm-chip" style="background:' + (SLOT_COLORS[g.slot] || '#666') + '">' + (g.slot ? 'P' + g.slot : '–') + '</span>' +
          '<span class="grow">' + esc(g.label) + (g.ping ? ' <span class="tm-muted">' + g.ping + ' ms</span>' : '') + '</span>' +
          slotSelect(g.slot, 'data-guest="' + esc(g.id) + '"', 'Spectate') +
          '<button class="tm-btn sec" data-kick="' + esc(g.id) + '" type="button" title="Remove">✕</button></div>';
      });
      var pc = 0; try { pc = runtime && runtime.globalVars.playersCount | 0; } catch (e) {}
      h += '<p class="tm-muted" style="margin-top:8px">Friends take Player 2, 3, 4 in order. Make sure the game is set to ' +
        (pc ? 'at least ' + (1 + hosting.guests.size) + ' players (currently ' + pc + ')' : 'enough players') + '.</p>' +
        '<button class="tm-btn bad full" data-act="stop" type="button" style="margin-top:6px">Stop hosting</button>';
      return h;
    }
    return '<h4>Online</h4><button class="tm-btn bad full" data-act="leave" type="button">Leave game</button>';
  }

  function onPanelClick(e) {
    var t = e.target;
    while (t && t !== panel && !(t.getAttribute && (t.getAttribute('data-tab') || t.hasAttribute('data-act') || t.hasAttribute('data-hcmode') || t.hasAttribute('data-hclvl') || t.hasAttribute('data-kick')))) t = t.parentNode;
    if (!t || t === panel) return;
    var v;
    if ((v = t.getAttribute('data-tab'))) { activeTab = v; render(); return; }
    if ((v = t.getAttribute('data-hcmode'))) { cfg.hcMode = v; saveCfg(); render(); return; }
    if ((v = t.getAttribute('data-hclvl'))) { cfg.hcLevel = parseInt(v, 10); saveCfg(); render(); return; }
    if ((v = t.getAttribute('data-kick'))) { var g = hosting && hosting.guests.get(v); if (g) dropGuest(g, 'was removed'); return; }
    v = t.getAttribute('data-act');
    if (v === 'host') startHosting();
    else if (v === 'join') joinGame(joinDraft);
    else if (v === 'stop') stopHosting();
    else if (v === 'leave') leaveGame('');
    else if (v === 'copy' && hosting) {
      var done = function () { toast('Code copied'); };
      try { navigator.clipboard.writeText(hosting.code).then(done, done); } catch (x) { done(); }
    }
  }
  function onPanelChange(e) {
    var t = e.target;
    if (t.hasAttribute('data-pad')) { padSlot[t.getAttribute('data-pad')] = parseInt(t.value, 10); render(); }
    else if (t.hasAttribute('data-guest')) setGuestSlot(t.getAttribute('data-guest'), parseInt(t.value, 10));
  }

  // ------------------------------------------------------------------ boot
  function boot() {
    buildUI();
    requestAnimationFrame(frame);
  }
  if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);

  // leave cleanly when the window closes
  window.addEventListener('beforeunload', function () {
    try { if (guest) leaveGame(''); if (hosting) stopHosting(); } catch (e) {}
  });

  // public surface (also used by tests)
  window.__tagMods = {
    version: VERSION,
    toggle: togglePanel,
    get runtime() { return runtime; },
    get hosting() { return hosting; },
    get guest() { return guest; },
    state: function () { return { cfg: cfg, hc: { leader: hc.leader, tagger: hc.tagger, active: hc.active, tagTime: hc.tagTime }, padSlot: padSlot, guestMode: guestMode, online: onlineState }; },
    startHosting: startHosting, stopHosting: stopHosting, joinGame: joinGame, leaveGame: leaveGame,
    setHandicap: function (mode, level) { cfg.hcMode = mode; if (level) cfg.hcLevel = level; saveCfg(); }
  };

  // hook into the Construct runtime
  function attach() {
    if (typeof self.runOnStartup !== 'function') return setTimeout(attach, 0);
    self.runOnStartup(async function (rt) {
      runtime = rt;
      rt.addEventListener('tick', hcTick);
    });
  }
  attach();
})();
