#!/bin/bash
# One-time build: compiles the native Tag window and signs the app. Run in Terminal:  ./build.sh
set -e
cd "$(dirname "$0")"

if ! command -v swiftc >/dev/null 2>&1; then
  echo "Swift compiler not found. Run:  xcode-select --install   then run ./build.sh again."
  exit 1
fi

APP="Tag.app"
mkdir -p "$APP/Contents/MacOS"
swiftc -O -o "$APP/Contents/MacOS/Tag" src/main.swift -framework Cocoa -framework WebKit
chmod +x "$APP/Contents/MacOS/Tag"
xattr -cr "$APP"
codesign --force --deep --sign - "$APP"
echo "Built $APP. Drag it to /Applications (or the Dock) and open it."
