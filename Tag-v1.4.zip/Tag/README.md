# Tag — folder contents

1. Run `./build.sh` in Terminal. It compiles the window and re-signs the app (required: index.html changed).
2. Drag `Tag-1.app` to /Applications and open it.

## What's new (v1.4)
Open the options panel with the 🎮 button (bottom-right) or **F2**.

- **Gamepads** – plug in / pair up to 4 controllers. Each drives one player (assignable in the panel).
  Stick or D-pad = move, any face button / shoulder = jump, Start = pause. Menus are still mouse-clicked.
- **Handicap** – Off / Tagger boost / Leader slow / Both, at Light / Medium / Strong.
  Tagger boost: +8 / +15 / +25 % speed for whoever is "it".
  Leader slow: −5 / −10 / −15 % for the player who has been "it" least (by 3+ s).
- **Online play** – Online tab → *Host a game* shows a 5-letter room code. Friends open the game
  (the app, or index.html in any current browser), choose *Join game*, type the code.
  The host's machine runs the match and streams video + sound; friends send their controls
  (A/D/W, arrows, Space, or a gamepad) and take Player 2–4. Up to 3 friends.

## Files
- `Tag-1.app/Contents/Resources/index.html` – the game.
- `mods/tag-mods.js` – readable source of all new features; `mods/peerjs.min.js` – PeerJS 1.5.4 (matchmaking/WebRTC).
- `tools/bundle_mods.py` – re-inject the mods after editing: `python3 tools/bundle_mods.py Tag-1.app/Contents/Resources/index.html Tag-1.app/Contents/Resources/index.html`
- Your `juke-*.mov` / `taunt.mov` files are unchanged and not included here (size limit) — keep them in your folder.

## Online play notes
- Matchmaking uses the free public PeerJS cloud server (0.peerjs.com) plus Google STUN. Game data is peer-to-peer.
  Strict corporate/school networks may block it (no TURN relay). To use your own servers, set
  `window.TAG_NET = {host, port, path, secure, iceServers}` before the game loads.
- Latency is video-stream latency (typically 50–150 ms on a good connection).
