#!/usr/bin/env python3
"""Inject mods/tag-mods.js (+ the PeerJS library) into the game's single-file index.html.

Usage:  python3 tools/bundle_mods.py <input index.html> <output index.html>

Safe to run on an already-patched file: the mod files are replaced and the
runtime options are only patched once.  Edit mods/tag-mods.js, then re-run this.
"""
import base64, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
MODS = os.path.join(HERE, '..', 'mods')
MAIN = 'scripts/tag-mods.js'

def b64(path):
    return base64.b64encode(open(path, 'rb').read()).decode('ascii')

def main(src, dst):
    html = open(src, encoding='utf-8').read()
    m = re.search(r'(<script id="vfs" type="application/json">)(.*?)(</script>)', html, re.S)
    if not m:
        sys.exit('vfs block not found - is this the single-file Tag build?')
    files = json.loads(m.group(2))

    files[MAIN] = {'t': 'application/javascript', 'd': b64(os.path.join(MODS, 'tag-mods.js'))}
    files['scripts/peerjs.min.js'] = {'t': 'application/javascript', 'd': b64(os.path.join(MODS, 'peerjs.min.js'))}

    main_js = base64.b64decode(files['scripts/main.js']['d']).decode('utf-8')
    new_opts = 'projectScripts: [["%s", ""]],\n            mainProjectScript: "%s",' % (MAIN, MAIN)
    pat = re.compile(r'projectScripts: \[.*?\],\s*mainProjectScript: "[^"]*",', re.S)
    if not pat.search(main_js):
        sys.exit('could not find the runtime options in main.js')
    main_js = pat.sub(lambda _: new_opts, main_js, count=1)
    files['scripts/main.js']['d'] = base64.b64encode(main_js.encode('utf-8')).decode('ascii')

    out = html[:m.start(2)] + json.dumps(files, separators=(',', ':')) + html[m.end(2):]
    open(dst, 'w', encoding='utf-8').write(out)
    print('wrote', dst, '(%.1f MB)' % (len(out) / 1e6))

if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(*sys.argv[1:])
